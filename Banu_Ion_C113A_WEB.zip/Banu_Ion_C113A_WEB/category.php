<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products by Category</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:whitesmoke;
            margin: 0;
            padding: 20px;
            color: #333;
        }
       
        .heading {
            text-align: center;
            color: #444;
            margin-bottom: 20px;
        }
        .products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            padding: 10px;
        }
        .product {
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            padding: 10px;
            border-radius: 8px;
            text-align: center;
        }
        img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }
        h3, p {
            margin: 10px 0;
        }
        .btn-back {
            display: block;
            width: 200px;
            padding: 10px;
            margin: 20px auto;
            text-align: center;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn-back:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<?php
// Establish database connection
$conn = new mysqli("localhost", "root", "", "shop");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the 'category' GET parameter is set and not empty
if (isset($_GET['category']) && !empty($_GET['category'])) {
    $categoryName = $_GET['category'];

    // Prepare a statement to avoid SQL injection
    $stmt = $conn->prepare("SELECT c.categorie_id FROM categorie_produs c JOIN produse p ON c.categorie_id = p.categorie_id WHERE c.nume_categorie = ? AND p.user_id = 2 GROUP BY c.categorie_id");
    $stmt->bind_param("s", $categoryName);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $categoryId = $row['categorie_id'];

        // Now get the products for this category that belong to user_id 2
        $stmt = $conn->prepare("SELECT p.produs_id, p.nume_produs, p.pret, p.cantitate, p.cale_imagine FROM produse p WHERE p.categorie_id = ? AND p.user_id = 2");
        $stmt->bind_param("i", $categoryId);
        $stmt->execute();
        $productsResult = $stmt->get_result();

        echo "<h1 class='heading'>Products in '" . htmlspecialchars($categoryName) . "' Category</h1>";
        if ($productsResult->num_rows > 0) {
            echo "<div class='products'>";
            while ($product = $productsResult->fetch_assoc()) {
                echo "<div class='product'>";
                echo "<img src='" . htmlspecialchars($product['cale_imagine']) . "' alt='" . htmlspecialchars($product['nume_produs']) . "'>";
                echo "<h3>" . htmlspecialchars($product['nume_produs']) . "</h3>";
                echo "<p>Price: $" . htmlspecialchars($product['pret']) . "</p>";
                echo "</div>";
            }
            echo "</div>";
        } else {
            echo "<p>No products found in this category for user ID 2.</p>";
        }
    } else {
        echo "<p>No such category found for user ID 2.</p>";
    }
    $stmt->close();
} else {
    echo "<p>Category not specified.</p>";
}
$conn->close();
?>
<a href="http://localhost/Tehnologii_WEB_proiect/index1.php" class="btn-back">Go Back</a>
</body>
</html>
