<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Vizualizează și Șterge Comenzi</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form, .links, .commands {
            margin-top: 20px;
            text-align: center;
        }
        input[type="number"], input[type="submit"], .button {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            display: block;
        }
        input[type="submit"], .button {
            background-color: #007bff;
            color: white;
            cursor: pointer;
        }
        input[type="submit"]:hover, .button:hover {
            background-color: #0056b3;
        }
        .button {
            text-decoration: none;
            text-align: center;
            display: inline-block;
            width: auto;
            margin: 10px 5px;
        }
        .comanda-list {
            text-align: left;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Vizualizează și Șterge Comenzi</h1>
        <form action="sterge_comenzi.php" method="post">
            <label for="comandaId">ID Comandă:</label>
            <input type="number" id="comandaId" name="comandaId" required>
            <input type="submit" name="submitDelete" value="Șterge Comandă">
        </form>
        <form action="sterge_comenzi.php" method="post">
            <input type="submit" name="showCommands" value="Afișează Comenzi" class="button">
        </form>
        <div class="links">
            <a href="index.html" class="button">Înapoi la Login</a>
            <a href="admin.html" class="button">Înapoi la Admin</a>
        </div>
    </div>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shop";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Conexiunea a eșuat: " . $conn->connect_error);
    }

    if (isset($_POST['submitDelete'])) {
        $comandaId = $_POST['comandaId'];
        $sql = "DELETE FROM produse_comanda WHERE comanda_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $comandaId);
        $stmt->execute();
        $sql = "DELETE FROM comenzi WHERE comanda_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $comandaId);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            echo "<p>Comanda cu ID-ul $comandaId a fost ștearsă cu succes.</p>";
        } else {
            echo "<p>Nu a fost găsită o comandă cu ID-ul specificat pentru ștergere.</p>";
        }
        $stmt->close();
    }

    if (isset($_POST['showCommands'])) {
        $sql = "SELECT comanda_id, data_si_ora, total_comanda FROM comenzi";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            echo "<div class='comanda-list'><strong>Lista comenzilor:</strong>";
            while ($row = $result->fetch_assoc()) {
                echo "<p>ID: " . $row["comanda_id"] . " - Data: " . $row["data_si_ora"] . " - Total: " . $row["total_comanda"] . "</p>";
            }
            echo "</div>";
        } else {
            echo "<p>Nu există comenzi de afișat.</p>";
        }
    }

    $conn->close();
    ?>
</body>
</html>
