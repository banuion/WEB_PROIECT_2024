<?php
session_start();
$response = ['success' => false, 'message' => 'Something went wrong', 'newTotal' => 0];

if (isset($_POST['index'])) {
    $index = intval($_POST['index']);
    if (isset($_SESSION['cart'][$index])) {
       
       
       
       
        unset($_SESSION['cart'][$index]); // Remove item from cart
        
        $_SESSION['cart'] = array_values($_SESSION['cart']); // Reindex array
        
        // Recalculate total
        $newTotal = 0;
        foreach ($_SESSION['cart'] as $item) {
            $newTotal += $item['pret'] * $item['cantitate'];
        }

        $response = [
            'success' => true,
            'message' => 'Item removed successfully.',
            'newTotal' => $newTotal // Provide new total for the cart
        ];

        
    } else {
        $response['message'] = 'Item not found in cart.';
    }
} else {
    $response['message'] = 'No index provided.';
}

echo json_encode($response);
?>




