<?php
// Verifică dacă formularul a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Începe sesiunea
    session_start();

    // Configurația conexiunii la baza de date
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shop";

    // Crează o conexiune
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verifică conexiunea
    if ($conn->connect_error) {
        die("Conexiunea a eșuat: " . $conn->connect_error);
    }

    // Colectează datele din formular
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $mobile = $conn->real_escape_string($_POST['mobile']);
    $gender = $conn->real_escape_string($_POST['gender']);

    // Verifică dacă parolele se potrivesc
    if ($password === $repassword) {
        // Criptează parola înainte de a o insera în baza de date
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        // Pregătește și execută interogarea SQL
        $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $email, $passwordHash);

        // Execută și verifică dacă interogarea a reușit
        if ($stmt->execute()) {
            echo "Înregistrarea a fost un succes!";
        } else {
            echo "Eroare: " . $stmt->error;
        }

        // Închide statement-ul și conexiunea
        $stmt->close();
        $conn->close();
    } else {
        echo "Parolele nu se potrivesc.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta
			name="viewport"
			content="width=device-width, initial-scale=1.0"
		/>
		<title>Registration Form</title>
		<style>
			body {
				font-family: Arial, sans-serif;
				background-color: #f3f3f3;
				margin: 0;
				padding: 0;
				display: flex;
				justify-content: center;
				align-items: center;
				height: 100vh;
			}
            .back-button {
            display: block;
            width: 100%;
            margin-top: 10px;
            background-color: #555;
            color: white;
            padding: 10px 1px;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .back-button:hover {
            background-color: #333;
        }
			.main {
				background-color: #fff;
				border-radius: 15px;
				box-shadow: 0 0 20px
					rgba(0, 0, 0, 0.2);
				padding: 20px;
				width: 300px;
			}
			html {
  font-size: 150%;
  overflow-x: hidden;
  scroll-behavior: smooth;
  scroll-padding-top: 7rem;
}
			.main h2 {
				color: #4caf50;
				margin-bottom: 20px;
			}

			label {
				display: block;
				margin-bottom: 5px;
				color: #555;
				font-weight: bold;
			}

			input[type="text"],
			input[type="email"],
			input[type="password"],
			select {
				width: 100%;
				margin-bottom: 15px;
				padding: 10px;
				box-sizing: border-box;
				border: 1px solid #ddd;
				border-radius: 5px;
			}

			button[type="submit"] {
				padding: 15px;
				border-radius: 10px;
				border: none;
				background-color: #4caf50;
				color: white;
				cursor: pointer;
				width: 100%;
				font-size: 16px;
			}
		</style>
	</head>

	<body>
		<div class="main">
			<h2>Registration User</h2>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
			

				<label for="email">Email:</label>
				<input
					type="email"
					id="email"
					name="email"
					required
				/>

				<label for="password"
					>Password:</label
				>
				<input
					type="password"
					id="password"
					name="password"
					
					title="Password must contain at least one number, 
						one alphabet, one symbol, and be at 
						least 8 characters long"
					required
				/>

				<label for="repassword"
					>Re-type Password:</label
				>
				<input
					type="password"
					id="repassword"
					name="repassword"
					required
				/>

				<label for="mobile"
					>Contact:</label
				>
				<input
					type="text"
					id="mobile"
					name="mobile"
					maxlength="10"
					required
				/>

				<label for="gender"
					>Gender:</label
				>
				<select
					id="gender"
					name="gender"
					required
				>
					<option value="male">
						Male
					</option>
					<option value="female">
						Female
					</option>
					<option value="other">
						Other
					</option>
				</select>

				<button type="submit">
					Submit
				</button>
			</form>
            <a href="index.html" class="back-button">Back to Login</a>
		</div>
	</body>
</html>
