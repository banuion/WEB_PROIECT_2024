<?php
session_start();

// Configurare conexiune la baza de date
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";

// Creare conexiune
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifică conexiunea
if ($conn->connect_error) {
    die("Conexiune eșuată: " . $conn->connect_error);
}

// Inițializează mesajul pentru utilizator
$message = '';

// Verifică dacă formularul a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $parola = $conn->real_escape_string($_POST['parola']);

    // Prepară interogarea SQL
    $stmt = $conn->prepare("SELECT user_id, password FROM Users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($parola, $row['password'])) {
            // Parola este corectă
            $_SESSION['id'] = $row['user_id'];
            $message = 'Login successful!';

            // Verifică dacă utilizatorul este admin
            if ($email == "admin@mta.ro") {
                header("Location: http://localhost/Tehnologii_WEB_proiect/admin.html");
                exit();
            } else {
                header("Location: http://localhost/Tehnologii_WEB_proiect/index1.php");
                exit();
            }
        } else {
            // Parola nu este corectă
            $message = 'Incorrect password or email!';
        }
    } else {
        $message = 'Incorrect password or email!';
    }
    $stmt->close();
}

$conn->close(); // Închide conexiunea

// Dacă login-ul a eșuat, salvează mesajul în sesiune și redirecționează înapoi la pagina de login
if ($message !== 'Login successful!') {
    $_SESSION['error_message'] = $message;
    header("Location: http://localhost/Tehnologii_WEB_proiect/index.html"); 
    exit();
}
?>
