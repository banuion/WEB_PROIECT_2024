<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Șterge Produs</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .button, .link-button {
            background-color: #007BFF;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
            text-decoration: none; /* Pentru a preveni sublinierea butoanelor care sunt linkuri */
            display: block; /* Facem butoanele să fie blocuri pentru a le alinia ușor */
            width: 300px; /* O lățime fixă pentru toate butoanele */
            text-align: center; /* Textul în centru butonului */
            margin-left: auto;
            margin-right: auto;
        }
        .button:hover, .link-button:hover {
            background-color: #0056b3;
        }
        form, .links {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center; /* Centrează conținutul pe verticală */
        }
        input[type="number"] {
            padding: 10px;
            margin-top: 5px;
            width: 280px; /* Lățimea să corespundă cu a butoanelor */
            border-radius: 5px;
            border: 1px solid #ddd;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>

</head>
<body>
    <h1>Șterge Produs</h1>
    <div class="forms">
        <form action="sterge_produs.php" method="post">
            <input type="submit" name="displayProducts" value="Afișează Produse" class="button">
        </form>
        <form action="sterge_produs.php" method="post">
            <input type="number" name="productId" placeholder="Introdu ID-ul produsului" required>
            <input type="submit" name="deleteProduct" value="Șterge Produs" class="button">
        </form>
    </div>
    <div class="links">
        <!-- Buton de navigare înapoi la pagina de admin -->
        <a href="http://localhost/Tehnologii_WEB_proiect/admin.html" class="link-button">Înapoi la Admin</a>
        <!-- Buton de navigare înapoi la pagina index -->
        <a href="http://localhost/Tehnologii_WEB_proiect/index.html" class="link-button">Înapoi la Login</a>
    </div>

    <?php
    // Include aici conexiunea la baza de date sau codul de conectare
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shop";
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Afisează produsele
    if(isset($_POST['displayProducts'])) {
     
        $sql = "SELECT * FROM produse WHERE user_id = 2";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<div><strong>Produse:</strong><br>";
            while($row = $result->fetch_assoc()) {
                echo "ID: " . $row["produs_id"]. " - Nume: " . $row["nume_produs"]. "<br>";
            }
            echo "</div>";
        } else {
            echo "Nu există produse adăugate de user_id = 2.";
        }
    }

    // Șterge un produs
    if(isset($_POST['deleteProduct'])) {
        $productId = $_POST['productId'];
        $sql = "DELETE FROM produse WHERE produs_id = ? AND user_id = 2";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $productId);
        $stmt->execute();

        if($stmt->affected_rows > 0) {
            echo "Produsul a fost șters.";
        } else {
            echo "Nu a fost găsit niciun produs cu ID-ul specificat sau nu aveți permisiunea de a șterge acest produs.";
        }
        $stmt->close();
    }

    $conn->close();
    ?>
</body>
</html>
