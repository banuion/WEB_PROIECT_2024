<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Șterge Utilizator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .button, .link-button {
            background-color: #007BFF;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
            text-decoration: none; /* Pentru a preveni sublinierea butoanelor care sunt linkuri */
            display: block; /* Facem butoanele să fie blocuri pentru a le alinia ușor */
            width: 300px; /* O lățime fixă pentru toate butoanele */
            text-align: center; /* Textul în centru butonului */
        }
        .button:hover, .link-button:hover {
            background-color: #0056b3;
        }
        form, .links {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center; /* Centrează conținutul pe verticală */
        }
        input[type="number"] {
            padding: 10px;
            margin-top: 5px;
            width: 280px; /* Lățimea să corespundă cu a butoanelor */
        }
    </style>
</head>
<body>
    <h1>Șterge Utilizator</h1>
    <div class="forms">
        <form action="sterge_user.php" method="post">
            <input type="submit" name="displayUsers" value="Afișează Utilizatori" class="button">
        </form>
        <form action="sterge_user.php" method="post">
            <input type="number" name="userId" placeholder="Introdu ID-ul utilizatorului" required>
            <input type="submit" name="deleteUser" value="Șterge Utilizator" class="button">
        </form>
    </div>
    <div class="links">
        <!-- Buton de navigare înapoi la pagina de admin -->
        <a href="http://localhost/Tehnologii_WEB_proiect/admin.html" class="link-button">Înapoi la Admin</a>
        <!-- Buton de navigare înapoi la pagina index -->
        <a href="http://localhost/Tehnologii_WEB_proiect/index.html" class="link-button">Înapoi la Index</a>
    </div>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shop";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexiunea a eșuat: " . $conn->connect_error);
    }

    if(isset($_POST['displayUsers'])) {
        $sql = "SELECT * FROM users WHERE user_id != 2";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<div><strong>Utilizatori:</strong><br>";
            while($row = $result->fetch_assoc()) {
                echo "ID: " . $row["user_id"]. " - Email: " . $row["email"]. "<br>";
            }
            echo "</div>";
        } else {
            echo "Nu există utilizatori.";
        }
    }

    if(isset($_POST['deleteUser'])) {
        $userId = $_POST['userId'];
        $sql = "DELETE FROM users WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        if($stmt->affected_rows > 0) {
            echo "Utilizatorul a fost șters.";
        } else {
            echo "Nu a fost găsit niciun utilizator cu ID-ul specificat.";
        }
        $stmt->close();
    }

    $conn->close();
    ?>
</body>
</html>
