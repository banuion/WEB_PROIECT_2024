
<?php
//include('config.php'); // Include setările de conectare la baza de date aici.
$servername = "localhost";
$username = "root";
$password = ""; // your database password
$dbname = "shop"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Verifică dacă formularul a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {

    // Procesează încărcarea fișierului
    $target_dir = "imagine/"; // Directorul unde se vor salva imaginile încărcate.
    $target_file = $target_dir . basename($_FILES["cale_imagine"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Verifică dacă fișierul este o imagine reală sau un fals
    if(isset($_FILES["cale_imagine"])) {
        $check = getimagesize($_FILES["cale_imagine"]["tmp_name"]);
        if($check !== false) {
            echo "Fișierul este o imagine - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "Fișierul nu este o imagine.";
            $uploadOk = 0;
        }
    }

    // Verifică dacă $uploadOk este setat pe 0 de o eroare
    if ($uploadOk == 0) {
        echo "Ne pare rău, fișierul tău nu a fost încărcat.";
    // dacă totul este ok, încearcă să încarci fișierul
    } else {
        if (move_uploaded_file($_FILES["cale_imagine"]["tmp_name"], $target_file)) {
            echo "Fișierul ". htmlspecialchars( basename( $_FILES["cale_imagine"]["name"])). " a fost încărcat.";

            // Inserarea detaliilor în baza de date
            $nume_produs = $_POST['nume_produs'];
            $pret = $_POST['pret'];
            $categorie_id = $_POST['categorie_id'];
            $user_id = 2; // 
            $cantitate = 1;
            // Conectare la baza de date și pregătirea instrucțiunii SQL
            $stmt = $conn->prepare("INSERT INTO produse (nume_produs, pret,cantitate, cale_imagine, categorie_id, user_id) VALUES (?,?, ?, ?, ?, ?)");
            $stmt->bind_param("sdissi", $nume_produs, $pret,$cantitate, $target_file, $categorie_id, $user_id);

            // Execută instrucțiunea
            if ($stmt->execute()) {
                echo "Produsul a fost adăugat cu succes.";
            } else {
                echo "Eroare la inserarea produsului: " . $stmt->error;
            }

            // Închide instrucțiunea și conexiunea
            $stmt->close();
            $conn->close();

        } else {
            echo "Ne pare rău, a apărut o eroare la încărcarea fișierului tău.";
        }
    }
} else {
    echo "Formular invalid.";
}


header("Location: http://localhost/Tehnologii_WEB_proiect/adauga_produs.php");
?>



