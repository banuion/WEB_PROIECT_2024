-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2024 at 12:12 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorie_produs`
--

CREATE TABLE `categorie_produs` (
  `categorie_id` int(11) NOT NULL,
  `nume_categorie` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categorie_produs`
--

INSERT INTO `categorie_produs` (`categorie_id`, `nume_categorie`) VALUES
(1, 'Vegetables'),
(2, 'Fresh'),
(3, 'Daily Products'),
(4, 'Fresh Meat');

-- --------------------------------------------------------

--
-- Table structure for table `comenzi`
--

CREATE TABLE `comenzi` (
  `comanda_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `data_si_ora` datetime DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `adresa_destinatie` varchar(255) DEFAULT NULL,
  `total_comanda` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comenzi`
--

INSERT INTO `comenzi` (`comanda_id`, `user_id`, `data_si_ora`, `telefon`, `adresa_destinatie`, `total_comanda`) VALUES
(14, 1, '2024-04-23 23:47:10', '0723454322', 'ion radulescu', 101.00),
(15, 1, '2024-04-23 23:53:29', '983', 'babes', 93.00),
(16, 7, '2024-04-23 23:54:38', '888', 'babes boia', 414.00),
(17, 1, '2024-04-23 23:57:55', '123', 'macul verde', 153.97),
(18, 7, '2024-04-23 23:59:41', '455', 'foca', 350.00),
(19, 8, '2024-04-24 00:14:26', '890', 'danut acasa', 180.00);

-- --------------------------------------------------------

--
-- Table structure for table `produse`
--

CREATE TABLE `produse` (
  `produs_id` int(11) NOT NULL,
  `nume_produs` varchar(255) NOT NULL,
  `pret` decimal(10,2) NOT NULL,
  `cantitate` int(11) NOT NULL,
  `cale_imagine` varchar(255) NOT NULL,
  `categorie_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produse`
--

INSERT INTO `produse` (`produs_id`, `nume_produs`, `pret`, `cantitate`, `cale_imagine`, `categorie_id`, `user_id`) VALUES
(39, 'oua', 15.99, 1, 'imagine/oua.jpeg', 2, 2),
(41, 'capsuni', 13.00, 1, 'imagine/capsuni.jpeg', 4, 2),
(43, 'Produs1', 8.00, 1, 'imagine/vegetablesfoodwhitebackground.jpg', 3, 2),
(44, 'dovleac', 12.00, 1, 'imagine/dovleac.jpeg', 2, 2),
(53, 'suc', 10.00, 0, 'imagine/Alimente.jpg', 1, 2),
(101, 'bradulet', 10.00, 0, 'imagine/Screenshot 2024-04-18 100113.png', 1, 2),
(104, 'bere', 12.00, 1, 'imagine/Screenshot 2024-04-19 091831.png', 1, 2),
(106, 'foca', 14.00, 1, 'imagine/Screenshot 2024-04-21 192134.png', 4, 2),
(154, 'Produs1', 8.00, 1, 'imagine/vegetablesfoodwhitebackground.jpg', 3, 8),
(155, 'dovleac', 12.00, 3, 'imagine/dovleac.jpeg', 2, 8),
(156, 'dovleac', 12.00, 3, 'imagine/dovleac.jpeg', 2, 8),
(157, 'dovleac', 12.00, 5, 'imagine/dovleac.jpeg', 2, 8),
(158, 'suc', 10.00, 1, 'imagine/Alimente.jpg', 1, 8),
(159, 'bradulet', 10.00, 3, 'imagine/Screenshot 2024-04-18 100113.png', 1, 8),
(160, 'mac', 11.00, 1, 'imagine/Screenshot 2024-04-22 084502.png', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `produse_comanda`
--

CREATE TABLE `produse_comanda` (
  `produse_comanda_id` int(11) NOT NULL,
  `comanda_id` int(11) DEFAULT NULL,
  `nume_produs` varchar(255) DEFAULT NULL,
  `pret` decimal(10,2) DEFAULT NULL,
  `cantitate` int(11) DEFAULT NULL,
  `calc_imagine` varchar(255) DEFAULT NULL,
  `categorie_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produse_comanda`
--

INSERT INTO `produse_comanda` (`produse_comanda_id`, `comanda_id`, `nume_produs`, `pret`, `cantitate`, `calc_imagine`, `categorie_id`) VALUES
(28, 14, 'Produs1', 8.00, 3, 'imagine/vegetablesfoodwhitebackground.jpg', 3),
(29, 14, 'capsuni', 13.00, 5, 'imagine/capsuni.jpeg', 4),
(30, 14, 'dovleac', 12.00, 1, 'imagine/dovleac.jpeg', 2),
(31, 15, 'Produs1', 8.00, 1, 'imagine/vegetablesfoodwhitebackground.jpg', 3),
(32, 15, 'capsuni', 13.00, 3, 'imagine/capsuni.jpeg', 4),
(33, 15, 'dovleac', 12.00, 3, 'imagine/dovleac.jpeg', 2),
(34, 15, 'suc', 10.00, 1, 'imagine/Alimente.jpg', 1),
(35, 16, 'bradulet', 10.00, 15, 'imagine/Screenshot 2024-04-18 100113.png', 1),
(36, 16, 'bere', 12.00, 21, 'imagine/Screenshot 2024-04-19 091831.png', 1),
(37, 16, 'dovleac', 12.00, 1, 'imagine/dovleac.jpeg', 2),
(38, 17, 'oua', 15.99, 3, 'imagine/oua.jpeg', 2),
(39, 17, 'foca', 14.00, 7, 'imagine/Screenshot 2024-04-21 192134.png', 4),
(40, 17, 'Produs1', 8.00, 1, 'imagine/vegetablesfoodwhitebackground.jpg', 3),
(41, 18, 'foca', 14.00, 25, 'imagine/Screenshot 2024-04-21 192134.png', 4),
(42, 19, 'Produs1', 8.00, 1, 'imagine/vegetablesfoodwhitebackground.jpg', 3),
(43, 19, 'dovleac', 12.00, 11, 'imagine/dovleac.jpeg', 2),
(44, 19, 'suc', 10.00, 1, 'imagine/Alimente.jpg', 1),
(45, 19, 'bradulet', 10.00, 3, 'imagine/Screenshot 2024-04-18 100113.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `review` text NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `review`, `user_id`) VALUES
(17, 'nu mi place mancarea', 1),
(18, 'imi place ciorba', 1),
(19, 'nu mi place inghetata', 1),
(20, 'ciocolata e calda', 1),
(22, 'nu e bun ceaiul\r\n', 8);

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `id` int(11) NOT NULL,
  `nume` varchar(255) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribe`
--

INSERT INTO `subscribe` (`id`, `nume`, `user_id`) VALUES
(1, 'ion.banu@mta.ro', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`) VALUES
(1, 'ban@mta', '$2y$10$Cue7LlbVtj/6nh..qn3.xuyg1it.ofyosit0dC7j2e2xBv0qwinYq'),
(2, 'admin@mta.ro', '$2y$10$Y2hSXBB.mM85yhjCFqchXOrSHye3VYio2weG22LU7Qc7LFrRM5qdO'),
(7, 'on@mta.com', '$2y$10$Cue7LlbVtj/6nh..qn3.xuyg1it.ofyosit0dC7j2e2xBv0qwinYq'),
(8, 'dan@mta', '$2y$10$8rxCdrljFPxrYIhBJ3/aRuqiVAv9035xz5tYcGP6vuseBpBvvwuhq');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorie_produs`
--
ALTER TABLE `categorie_produs`
  ADD PRIMARY KEY (`categorie_id`);

--
-- Indexes for table `comenzi`
--
ALTER TABLE `comenzi`
  ADD PRIMARY KEY (`comanda_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `produse`
--
ALTER TABLE `produse`
  ADD PRIMARY KEY (`produs_id`),
  ADD KEY `fk_user` (`user_id`);

--
-- Indexes for table `produse_comanda`
--
ALTER TABLE `produse_comanda`
  ADD PRIMARY KEY (`produse_comanda_id`),
  ADD KEY `comanda_id` (`comanda_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `fk_user_review` (`user_id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorie_produs`
--
ALTER TABLE `categorie_produs`
  MODIFY `categorie_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comenzi`
--
ALTER TABLE `comenzi`
  MODIFY `comanda_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `produse`
--
ALTER TABLE `produse`
  MODIFY `produs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT for table `produse_comanda`
--
ALTER TABLE `produse_comanda`
  MODIFY `produse_comanda_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comenzi`
--
ALTER TABLE `comenzi`
  ADD CONSTRAINT `comenzi_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `produse`
--
ALTER TABLE `produse`
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `produse_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `produse_comanda`
--
ALTER TABLE `produse_comanda`
  ADD CONSTRAINT `produse_comanda_ibfk_1` FOREIGN KEY (`comanda_id`) REFERENCES `comenzi` (`comanda_id`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `fk_user_review` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD CONSTRAINT `subscribe_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
