<?php
session_start(); // Inițializează sesiunea pentru a putea accesa variabilele de sesiune

// Distrugerea sesiunii
session_unset(); // Șterge toate variabilele de sesiune
session_destroy(); // Distrugere sesiune completă

// Redirecționare către pagina de login sau o altă pagină
header("Location: http://localhost/Tehnologii_WEB_proiect/index.html");
exit(); // Asigură-te că nu se execută cod PHP suplimentar după redirecționare
?>
