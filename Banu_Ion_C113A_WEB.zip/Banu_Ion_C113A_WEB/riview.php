<?php
session_start();

// Configurare conexiune la baza de date
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";

// Creare conexiune
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifică conexiunea
if ($conn->connect_error) {
    die("Conexiune eșuată: " . $conn->connect_error);
}

// Query to fetch review and user name
$sql = "SELECT r.review, u.name FROM review r JOIN Users u ON r.user_id = u.user_id";
$result = $conn->query($sql);

// Verifică dacă sunt rezultate
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<div class="swiper-slide box">';
        echo '<img src="imagine/mar.jpeg">'; // Presumed path to image
        echo '<p>' . htmlspecialchars($row['review']) . '</p>';
        echo '<h3>' . htmlspecialchars($row['name']) . '</h3>';
        echo '<div class="stars">';
        echo '<i class="fa fa-star"></i>';
        echo '<i class="fa fa-star"></i>';
        echo '<i class="fa fa-star"></i>';
        echo '<i class="fa fa-star"></i>';
        echo '<i class="fa fa-star-half"></i>';
        echo '</div>';
        echo '</div>';
    }
} else {
    echo "<p>No reviews found.</p>";
}

// Închide conexiunea
$conn->close();
?>
