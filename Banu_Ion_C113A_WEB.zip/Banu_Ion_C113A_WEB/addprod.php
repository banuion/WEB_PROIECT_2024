<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";

// Crează conexiunea la baza de date
$conn = new mysqli($servername, $username, $password, $dbname);
$userid = $_SESSION['id'] ?? null; 
// Verifică conexiunea
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Inițializează variabilele pentru a evita erorile de tip undefined index
$nume_produs = $pret = $cantitate = $cale_imagine = $categorie_id = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nume_produs = $_POST['nume_produs'] ?? 'Nedefinit';
    $pret = $_POST['pret'] ?? 0;
    $cantitate = $_POST['cantitate'] ?? 0;
    $cale_imagine = $_POST['cale_imagine'] ?? 'Nicio imagine';
    $categorie_id = $_POST['categorie_id'] ?? 0;
    echo "Date primite: Nume Produs: $nume_produs, Pret: $pret, Cantitate: $cantitate, Imagine: $cale_imagine, Categorie ID: $categorie_id";
      
       $found = false;
       foreach ($_SESSION['cart'] as &$item) {
           if ($item['nume_produs'] === $nume_produs) {
               $item['cantitate'] += $cantitate;
               $found = true;
               break;
           }
       }
       if (!$found) {
           $_SESSION['cart'][] = [
               'nume_produs' => $nume_produs,
               'pret' => $pret,
               'cantitate' => $cantitate,
               'cale_imagine' => $cale_imagine,
               'categorie_id' => $categorie_id
           ];
       }
    
       // Generează și returnează HTML-ul pentru coșul de cumpărături
    //   echo generateCartHTML($_SESSION['cart']);
    // Prepară o interogare SQL pentru a insera datele în baza de date
    $sql = "INSERT INTO produse (nume_produs, pret, cantitate, cale_imagine, categorie_id,user_id) VALUES (?, ?, ?, ?, ?, ?)";
    

    
    $stmt = $conn->prepare($sql);




    if (!$stmt) {
        echo "Eroare la prepararea interogării: " . $conn->error;
    } else {
        $stmt->bind_param("sdisii", $nume_produs, $pret, $cantitate, $cale_imagine, $categorie_id, $userid);

        if ($stmt->execute()) {
            echo "Produsul a fost adăugat cu succes!";
        } else {
            echo "Eroare la adăugarea produsului: " . $stmt->error;
        }

        $stmt->close();
    }
}




error_log("Încercare de inserare produs: " . print_r($_POST, true));
$_SESSION['message'] = "Produsul a fost adăugat cu succes: Nume Produs: $nume_produs, Pret: $pret, Cantitate: $cantitate, Imagine: $cale_imagine, Categorie ID: $categorie_id";

header("location:index1.php");
$conn->close();

?>

