<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Vizualizează Comenzi</title>
    <style>
       body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f7f7f7;
        margin: 0;
        padding: 20px;
        color: #333;
    }
    .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    h1 {
        color: #333;
        text-align: center;
        margin-bottom: 30px;
    }
    .comanda-container {
        background-color: #f9f9f9;
        border: 1px solid #e1e1e1;
        padding: 15px;
        margin-bottom: 10px;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        position: relative;
    }
    .comanda-container button {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        margin-top: 10px;
    }
    .comanda-container button:hover {
        background-color: #0056b3;
    }
    .detalii-comanda {
        background-color: #ffffff;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        display: none; /* inițial detaliile sunt ascunse */
        margin-top: 10px;
    }
    .detalii-comanda ul {
        list-style: none;
        padding: 0;
    }
    .detalii-comanda ul li {
        background-color: #eee;
        padding: 5px;
        margin-bottom: 5px;
        border-radius: 4px;
    }
    .link-button {
        background-color: #28a745;
        color: white;
        text-align: center;
        padding: 10px 15px;
        margin: 20px 0;
        display: inline-block;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }
    .link-button:hover {
        background-color: #218838;
    }
      
    @media (max-width: 768px) {
        .container {
            width: 95%;
            padding: 10px;
        }

        .comanda-container {
            padding: 10px;
        }

        .comanda-container button {
            width: 100%;
            margin-top: 10px; /* Adaugă un spațiu suplimentar pentru a nu lipi de text */
        }

        .link-button {
            width: 100%; /* Butonul de link să se întindă pe toată lățimea container-ului */
            box-sizing: border-box; /* Include padding-ul în lățimea totală */
        }

        .form-group input[type="number"], 
        .form-group input[type="submit"] {
            width: 90%; /* Micsorează lățimea input-urilor pentru a se potrivi pe ecrane mici */
        }

        .form-group, .links {
            width: 100%; /* Lățime completă pentru elemente în modul responsive */
        }

        h1 {
            font-size: 24px; /* Diminuează dimensiunea fontului pentru titlu */
        }
    }
        .comanda-container {
            background-color: #ffffff;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .detalii-comanda {
            display: none;
        }
    </style>
</head>
<body>
    <h1>Vizualizează Comenzi</h1>

    <div class="comenzi">
        <!-- Aici se afișează comenzile -->
        <?php
        $conn = new mysqli("localhost", "root", "", "shop");
        if ($conn->connect_error) {
            die("Conexiunea a eșuat: " . $conn->connect_error);
        }

        $sql = "SELECT comenzi.*, users.email FROM comenzi INNER JOIN users ON comenzi.user_id = users.user_id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($comanda = $result->fetch_assoc()) {
                echo "<div class='comanda-container'>";
                echo "<strong>ID Comandă:</strong> " . $comanda["comanda_id"] . " - <strong>Utilizator:</strong> " . $comanda["email"];
                echo "<button onclick='afiseazaDetalii(" . $comanda["comanda_id"] . ")' class='button'>Vezi Detalii</button>";
                echo "<div id='detalii-" . $comanda["comanda_id"] . "' class='detalii-comanda'>";
                echo "<p><strong>Data și Ora:</strong> " . $comanda["data_si_ora"] . "</p>";
                echo "<p><strong>Total Comandă:</strong> " . $comanda["total_comanda"] . "</p>";
                echo "<p><strong>Telefon:</strong> " . $comanda["telefon"] . "</p>";
                echo "<p><strong>Adresa de Destinație:</strong> " . $comanda["adresa_destinatie"] . "</p>";


                
                $sqlProduse = "SELECT * FROM produse_comanda WHERE comanda_id = " . $comanda["comanda_id"];
                $resultProduse = $conn->query($sqlProduse);
                if ($resultProduse->num_rows > 0) {
                    echo "<ul>";
                    while($produs = $resultProduse->fetch_assoc()) {
                        echo "<li>" . $produs["nume_produs"] . " - Cantitate: " . $produs["cantitate"] . ", Preț: " . $produs["pret"] . "</li>";
                    }
                    echo "</ul>";
                }
                echo "</div>"; // detalii-comanda
                echo "</div>"; // comanda-container
            }
        } else {
            echo "<p>Nu există comenzi.</p>";
        }
        $conn->close();
        ?>
    </div>

    <!-- Scriptul pentru afișarea și ascunderea detaliilor comenzilor -->
    <script>
        function afiseazaDetalii(comandaId) {
            var detalii = document.getElementById('detalii-' + comandaId);
            if (detalii.style.display === 'block') {
                detalii.style.display = 'none';
            } else {
                detalii.style.display = 'block';
            }
        }
    </script>

    <div class="links">
        <a href="index.html" class="link-button">Înapoi la Login</a>
        <a href="admin.html" class="link-button">Înapoi la Admin</a>
    </div>
</body>
</html>
