<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Newsletter</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e9eff1;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }

        .container {
            width: 100%;
            max-width: 600px;
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #0057b8;
        }

        textarea {
            width: calc(100% - 20px);
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            height: 150px;
            resize: vertical;
        }

        input[type="submit"] {
            background-color: #0057b8;
            color: #ffffff;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            letter-spacing: 1px;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #004a9d;
        }
    </style>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the message content from the form
    $subject = 'Admin Newsletter'; // You can customize this subject
    $message = $_POST['message']; // The message the admin wrote in the form
    $headers = 'From: banuion99@yahoo.com'; // Replace with your email

    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = ""; // Your database password
    $dbname = "shop"; // Your database name
    $tableName = "subscribe"; // Your table name
    $columnName = "nume"; // The column containing the email addresses

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL to get emails
    $sql = "SELECT $columnName FROM $tableName";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Loop through each email and send the message
        while ($row = $result->fetch_assoc()) {
            $to = $row[$columnName];
            if (!mail($to, $subject, $message, $headers)) {
                echo 'Mail sending failed for: ' . htmlspecialchars($to) . '<br>';
            } else {
                echo 'Mail sent successfully to ' . htmlspecialchars($to) . '<br>';
            }
        }
    } else {
        echo "No recipients found.";
    }

    // Close connection
    $conn->close();
}
?>

<!-- The HTML form for sending the newsletter -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <textarea name="message" rows="5" cols="35" placeholder="Write your message here..."></textarea><br>
    <input type="submit" value="Send Newsletter">
</form>

</body>
</html>

