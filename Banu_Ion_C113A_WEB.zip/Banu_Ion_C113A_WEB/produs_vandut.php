<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Top 3 Produse Vândute</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px;
            background-color: #f7f7f7;
            color: #333;
            line-height: 1.6;
        }
        h1 {
            text-align: center;
            color: #444;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        ol {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        li {
            border-bottom: 1px solid #eee;
            padding: 8px 0;
            font-size: 18px;
        }
        li:last-child {
            border-bottom: none;
        }
        .button {
            display: block;
            width: 200px;
            margin: 20px auto;
            background-color: #0056b3;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            font-size: 18px;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #003d82;
        }
        .back-buttons {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Top Produse Vândute</h1>

        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "shop";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Conexiunea a eșuat: " . $conn->connect_error);
        }

        // Interogarea pentru a afla topul produselor vândute bazat pe cantitate totală vândută
        $sql = "
            SELECT pc.nume_produs, SUM(pc.cantitate) AS total_vandut
            FROM produse_comanda AS pc
            JOIN comenzi AS c ON pc.comanda_id = c.comanda_id
            GROUP BY pc.nume_produs
            ORDER BY total_vandut DESC
            
        ";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<ol>"; // Începe o listă ordonată
            while($row = $result->fetch_assoc()) {
                echo "<li>" . $row["nume_produs"]. " - Total Vândut: " . $row["total_vandut"] . "</li>";
            }
            echo "</ol>"; // Încheie lista ordonată
        } else {
            echo "Nu există date suficiente pentru a genera un top al produselor vândute.";
        }

        $conn->close();
        ?>

        <div class="back-buttons">
            <a href="admin.html" class="button">Înapoi la Admin</a>
            <a href="index.html" class="button">Înapoi la Login</a>
        </div>
    </div>
</body>
</html>
