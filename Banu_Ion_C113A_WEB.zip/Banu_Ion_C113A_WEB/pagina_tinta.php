<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Confirmare Abonare</title>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = ""; // Adaugă parola aici dacă este necesar
$dbname = "shop";

// Crează conexiunea
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifică conexiunea
if ($conn->connect_error) {
    die("Conexiunea a eșuat: " . $conn->connect_error);
}

// Preia emailul trimis prin formular
$email = $_POST['email'];

// Pregătește o declarație SQL pentru a preveni injecțiile SQL
$stmt = $conn->prepare("INSERT INTO Subscribe (nume) VALUES (?)");
$stmt->bind_param("s", $email);

// Execută interogarea
if ($stmt->execute()) {
    echo "Te-ai abonat cu succes la newsletter!";
} else {
    echo "Eroare: " . $stmt->error;
}

// Închide declarația și conexiunea
$stmt->close();
$conn->close();

?>

</body>
</html>


<?php

header("Location: index1.php");
?>

