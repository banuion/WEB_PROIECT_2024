<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Adaugă Produs</title>
    <style>
        .container {
            max-width: 500px;
            margin: auto;
            padding: 20px;
            background-color: #f4f4f4;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select,
        .form-group button {
            width: 100%;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        .form-group button {
            background-color: #007BFF;
            color: white;
            border-color: #007BFF;
        }
        .form-group button:hover {
            background-color: #0056b3;
        }
        .back-button {
            text-decoration: none;
            padding: 8px 16px;
            background-color: #6c757d;
            color: white;
            border-radius: 4px;
            display: inline-block;
            margin-top: 20px;
        }
        .back-button:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Adaugă Produs Nou</h1>
    <form action="insert_produs.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nume_produs">Nume Produs:</label>
            <input type="text" id="nume_produs" name="nume_produs" required>
        </div>
        <div class="form-group">
            <label for="pret">Preț:</label>
            <input type="number" id="pret" name="pret" required step="0.01">
        </div>
        <div class="form-group">
            <label for="cale_imagine">Imagine:</label>
            <input type="file" id="cale_imagine" name="cale_imagine" required>
        </div>
        <div class="form-group">
            <label for="categorie_id">Categorie ID:</label>
            <select id="categorie_id" name="categorie_id" required>
                <option value="1">Vegetables</option>
                <option value="2">Fresh</option>
                <option value="3">Daily Products</option>
                <option value="4">Fresh Meat</option>
                </select>
        </div>
        <div class="form-group">
            <button type="submit" name="submit">Adaugă Produs</button>
        </div>
    </form>
    <a href="admin.html" class="back-button">Înapoi la Admin</a>
    <a href="index.html" class="back-button">Înapoi la Index</a>
</div>

</body>
</html>

