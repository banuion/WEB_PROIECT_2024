
let searchForm=document.querySelector('.search-form');
document.querySelector('#search-btn').onclick=()=>
{

searchForm.classList.toggle('active');
navbar.classList.remove('active');

shoppingCart.classList.remove('active');
loginForm.classList.remove('active');

}



document.getElementById('search-box').addEventListener('input', function() {
    var searchQuery = this.value.toLowerCase();
    var allTextItems = document.querySelectorAll('body *');

    allTextItems.forEach(function(item) {
        // Verifică dacă elementul are text vizibil și nu este un container mare
        if (item.offsetHeight > 0 && item.offsetWidth > 0 && !item.matches('header, footer, nav, section')) {
            if (item.textContent.toLowerCase().includes(searchQuery)) {
                item.style.display = ''; // Afișează elementul dacă corespunde căutării
            } else {
                item.style.display = 'none'; // Ascunde elementul dacă nu corespunde căutării
            }
        }
    });
});


document.addEventListener('scroll', function() {
    const home = document.getElementById('home');
    const scrollY = window.pageYOffset;

    home.style.backgroundPosition = 'center ' + scrollY * 0.5 + 'px';
  });
 
let shoppingCart=document.querySelector('.shopping-cart');
document.querySelector('#cart-btn').onclick=()=>
{

    shoppingCart.classList.toggle('active');
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    
    loginForm.classList.remove('active');
   
}

let loginForm=document.querySelector('.login-form');
document.querySelector('#login-btn').onclick=()=>
{

    loginForm.classList.toggle('active');
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');

  

}
let navbar=document.querySelector('.navbar');
document.querySelector('#menu-btn').onclick=()=>
{

    navbar.classList.toggle('active');
  
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
  

}
window.onscroll=()=>{
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
}


var swiper=new Swiper(".product-slider",{
   loop:true,
    spaceBetween:20,
   
autoplay:{
    delay:7500,
    disableOnInteraction:false,
},

breakpoints:{
    0:{
        slidesPerView:1,
   
    },
768:{
slidesPerView:2,

},
1020:{
    slidesPerView:3,
   
},
},
});




var swiper=new Swiper(".review-slider",{
    loop:true,
     spaceBetween:20,
    
 autoplay:{
     delay:7500,
     disableOnInteraction:false,
 },
 
 breakpoints:{
     0:{
         slidesPerView:1,
    
     },
 768:{
 slidesPerView:2,
 
 },
 1020:{
     slidesPerView:3,
    
 },
 },
 });
 

  
  
 
 document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.plus-btn, .minus-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const container = btn.closest('.swiper-slide');
            const input = container.querySelector('.quantity-input');
            const display = container.querySelector('.quantity-display');
            const isPlus = btn.classList.contains('plus-btn');
            let currentValue = parseInt(input.value, 10);

            if (isPlus) {
                currentValue += 1;
            } else if (currentValue > 1) {
                currentValue -= 1;
            }

            input.value = currentValue;
            display.textContent = currentValue;
        });
    });
});


