


<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "shop";

// Crează conexiunea la baza de date
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifică conexiunea
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verifică dacă metoda de request este POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $review = $_POST['review'] ?? 'No review provided';
    $user_id = $_SESSION['id'] ?? 0; // Preia ID-ul utilizatorului din sesiune

    // Prepară și execută interogarea SQL pentru inserarea recenziei
    $sql = "INSERT INTO review (user_id, review) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("is", $user_id, $review);
        if ($stmt->execute()) {
            echo "Review added successfully!";
           
        } else {
            echo "Error adding review: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

$conn->close();
header("Location: http://localhost/Tehnologii_WEB_proiect/index1.php");
?>


