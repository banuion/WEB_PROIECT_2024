<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comanda Ta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .form-container {
            background: #fff;
            max-width: 400px;
            margin: 30px auto;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box; /* Makes sure padding doesn't affect the total width */
        }

        .form-group input[type="submit"] {
            width: 100%;
            padding: 10px;
            background: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .form-group input[type="submit"]:hover {
            background: #4cae4c;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Finalizează Comanda</h2>
    <!-- Acesta va fi formularul tău pentru adresa de destinație și telefon -->
    <form action="comanda.php" name="submit_order" method="post">
        <div class="form-group">
            <label for="telefon">Telefon:</label>
            <input type="text" id="telefon" name="telefon" required>
        </div>
        
        <div class="form-group">
            <label for="adresa_destinatie">Adresa de Destinație:</label>
            <input type="text" id="adresa_destinatie" name="adresa_destinatie" required>
        </div>
        
        <div class="form-group">
            <input type="submit" value="Trimite Comanda">
        </div>
    </form>
</div>

</body>
</html>








<?php
session_start();// Presupunem că ai o conexiune la baza de date numită $conn

// db_config.php
$servername = "localhost";
$username = "root";
$password = ""; // your database password
$dbname = "shop"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $telefon = $_POST['telefon'];
        $adresaDestinatie = $_POST['adresa_destinatie'];
    $total = array_sum(array_map(function ($item) {
        return $item['pret'] * $item['cantitate'];
    }, $_SESSION['cart']));
echo "$total";
$user_id = $_SESSION['id'];
    // Pregătim declarația de inserare pentru tabelul `comenzi`
    $stmt = $conn->prepare("INSERT INTO comenzi (user_id, data_si_ora, telefon, adresa_destinatie, total_comanda) VALUES (?, NOW(), ?, ?, ?)");
    $stmt->bind_param("issd", $user_id, $telefon, $adresaDestinatie, $total);

    // Setează aici valorile variabilelor $userId, $telefon, $adresaDestinatie
    // ...
    
    // Executăm inserarea în tabelul `comenzi`
    $stmt->execute();
    $comandaId = $conn->insert_id; // Salvăm ID-ul comenzii inserate pentru a-l folosi în tabelul `produse_comanda`

    // Acum inserăm fiecare produs în tabelul `produse_comanda`
    $stmt = $conn->prepare("INSERT INTO produse_comanda (comanda_id, nume_produs, pret, cantitate, calc_imagine, categorie_id) VALUES (?, ?, ?, ?, ?, ?)");

    foreach ($_SESSION['cart'] as $item) {
        $stmt->bind_param("isdssi", $comandaId, $item['nume_produs'], $item['pret'], $item['cantitate'], $item['cale_imagine'], $item['categorie_id']);
        $stmt->execute();
    }

    $stmt->close();
    $conn->close();

    // Aici poți redirecționa utilizatorul la o pagină de mulțumire sau de confirmare a comenzii
   header("Location: index1.php");

//} else {
    echo "<p>$user_id.</p>";
//}

    }
?>
