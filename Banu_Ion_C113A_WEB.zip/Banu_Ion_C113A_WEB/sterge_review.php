<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Șterge Review</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f4f4f4;
        }
        .button, .link-button {
            background-color: #007BFF;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
            text-decoration: none;
            display: block;
            width: 300px;
            text-align: center;
            margin-left: auto;
            margin-right: auto;
        }
        .button:hover, .link-button:hover {
            background-color: #0056b3;
        }
        form, .links {
            margin-top: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input[type="number"] {
            padding: 10px;
            margin-top: 5px;
            width: 280px;
            border-radius: 5px;
            border: 1px solid #ddd;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body>
    <h1>Șterge Review</h1>
    <div class="forms">
        <form action="sterge_review.php" method="post">
            <input type="submit" name="displayReviews" value="Afișează Review-uri" class="button">
        </form>
        <form action="sterge_review.php" method="post">
            <input type="number" name="reviewId" placeholder="Introdu ID-ul review-ului" required>
            <input type="submit" name="deleteReview" value="Șterge Review" class="button">
        </form>
    </div>
    <div class="links">
        <!-- Buton de navigare înapoi la pagina de admin -->
        <a href="admin.html" class="link-button">Înapoi la Admin</a>
        <!-- Buton de navigare înapoi la pagina index -->
        <a href="index.html" class="link-button">Înapoi la Index</a>
    </div>

    <?php
    // Conexiunea la baza de date
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "shop";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Conexiunea a eșuat: " . $conn->connect_error);
    }

    // Afișează toate review-urile
    if(isset($_POST['displayReviews'])) {
        $sql = "SELECT * FROM review"; // Interogare pentru toate review-urile
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<div><strong>Review-uri:</strong><br>";
            while($row = $result->fetch_assoc()) {
                echo "ID: " . $row["review_id"]. " - Review: " . $row["review"] . " - User ID: " . $row["user_id"] . "<br>";
            }
            echo "</div>";
        } else {
            echo "Nu există review-uri.";
        }
    }

    // Șterge un review specificat de ID
    if(isset($_POST['deleteReview'])) {
        $reviewId = $_POST['reviewId'];
        $sql = "DELETE FROM review WHERE review_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $reviewId);
        $stmt->execute();

        if($stmt->affected_rows > 0) {
            echo "Review-ul a fost șters.";
        } else {
            echo "Nu a fost găsit niciun review cu ID-ul specificat.";
        }
        $stmt->close();
    }

    $conn->close();
    ?>
    
</body>
</html>
