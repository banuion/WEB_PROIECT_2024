<?php
// Start the session at the very beginning of the script.
session_start();

// Output HTML header information before any PHP code to set the content type.
echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>User ID Display</title></head><body>';

// Use CSS to style the output. Here we're setting the font size to 24px.
echo '<style> .big-text { font-size: 30px; color: blue; } </style>';

// Check if the session variable is set before using it.
if (isset($_SESSION['id'])) {
    // Safe to use the session variable.
    $userId = $_SESSION['id'];
    // Output the user ID in a paragraph with large text.
    echo '<p class="big-text">USER ID: ' . htmlspecialchars($userId) . '</p>';
} else {
    // Handle the case where the session variable isn't set.
    echo '<p class="big-text">User ID is not set in the session.</p>';
}

// Close HTML tags.
echo '</body></html>';
?>

<?php
// db_config.php
$servername = "localhost";
$username = "root";
$password = ""; // your database password
$dbname = "shop"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta charset="UTF-8">
   
    <title>Doi pasi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/st.css">
    <link rel="stylesheet" type="text/css" href="css/style1.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

 
</head>
<body>
    
<header class="header">
     <a href="#" class="logo"> <i class="fa fa-shopping-basket" aria-hidden="true"></i> doi pasi</a>
   

<nav class="navbar">
<a href="#home">home</a> 
<a href="#features">features</a> 
<a href="#Products">Products</a> 
<a href="#Categories">Categories</a> 
<a href="#Review">Review</a> 
<a href="#Blocs">Blocs</a>    
</nav>

<div class="icons">
    <div class="fa fa-bars" id="menu-btn"></div>
<div class="fa fa-search" id="search-btn"></div>
<div class="fa fa-shopping-cart" id="cart-btn"></div>
<div class="fa fa-user" id="login-btn"></div>
</div>


<form class="search-form">
    <input type="search" id="search-box"  placeholder="Search Here
    .....">
    <label for="search-box" class="fa fa-search"> </label>
</form>


<div class="shopping-cart">
    <?php if (!empty($_SESSION['cart'])): ?>
        <?php 
        $total = 0; 
        foreach ($_SESSION['cart'] as $index => $item):
            $subtotal = $item['pret'] * $item['cantitate'];
            $total += $subtotal;
        ?>
            <div class="box" id="item-<?php echo $index; ?>">
                <i class="fa fa-trash" onclick="removeFromCart(<?php echo $index; ?>);"></i>
                <img src="<?php echo htmlspecialchars($item['cale_imagine']); ?>" alt="Product image">
                <div class="content">
                    <h3><?php echo htmlspecialchars($item['nume_produs']); ?></h3>
                    <span class="price">$<?php echo number_format($item['pret'], 2); ?> /-</span>
                    <span class="quantity">Qty: <?php echo $item['cantitate']; ?></span>
                </div>
            </div>
        <?php endforeach; ?>
        <div class="total">Total: $<?php echo number_format($total, 2); ?></div>
        <a href="comanda.php" class="btn">Checkout</a>
    <?php else: ?>
        <p>Your cart is empty.</p>
    <?php endif; ?>
</div>



<!--
<div class="shopping-cart">
<div class="box"> 
    <i class="fa fa-trash"> </i>
    <img src="imagine\images.jpeg">
    <div class="content">
    <h3>produs1</h3>
    <span class="price"> $5 /-</span>
    <span class="quantity">Qty : 1</span>
    </div>

    </div>

    <div class="box"> 
        <i class="fa fa-trash"> </i>
        <img src="imagine\fruits512.bmp">
        <div class="content">
        <h3>produs2</h3>
        <span class="price"> $6 /-</span>
        <span class="quantity">Qty : 1</span>
        </div>
    
        </div>

        <div class="box"> 
            <i class="fa fa-trash"> </i>
            <img src="imagine\fruits512.bmp">
            <div class="content">
            <h3>produs3</h3>
            <span class="price"> $7 /-</span>
            <span class="quantity">Qty : 1</span>
            </div>
        
            </div>


<div class="total"> total :18.97</div>

<a href="#" class="btn"> Checkout </a>

</div>
-->
<form action="logout.php" method="POST" class="login-form">
    <h3>Disconnect now</h3>
    <input type="submit" value="Disconnect Now" class="btn">
</form>





</header>

<section class="home" id="home">
<div class="content">
<h3>Fresh And<span> Organic</span> Products for you </h3>
<a href="#" class="btn">shop now</a>
</div>
</section>



<section class="features" id="features">
<h1 class="heading">our <span> features </span></h1>    



<div class="box-container">
<div class="box">
    <img src="imagine/vegetablesfoodwhitebackground.jpg">
    <h3>fresh And Organic</h3>
    <p>
        Carrot, Tomato, Potato, Onion, Lettuce, Cucumber, Broccoli, Cauliflower, Spinach, Bell pepper

    </p>
<a href="#" class="btn" >read more </a>
</div>

<div class="box">
    <img src="imagine/images4.jpeg">
    <h3>fresh And Organic</h3>
    <p>
        Carrot, Tomato, Potato, Onion, Lettuce, Cucumber, Broccoli, Cauliflower, Spinach, Bell pepper

    </p>
<a href="#" class="btn" >read more </a>
</div>
<div class="box">
    <img src="imagine/download2.jpeg">
    <h3>fresh And Organic</h3>
    <p>
        Carrot, Tomato, Potato, Onion, Lettuce, Cucumber, Broccoli, Cauliflower, Spinach, Bell pepper

    </p>
<a href="#" class="btn" >read more </a>
</div>


</div>





</section>

<!-- products-->
<section class="Products" id="Products">
<h1 class="heading"> Our <span> Products</span> </h1>

<div class="swiper product-slider">
    <div class="swiper-wrapper">
        <?php
        // Assume $conn is your database connection from previous examples.

        // SQL to select products where user_id is 2
        $sql = "SELECT * FROM produse WHERE user_id = 2";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                echo '<div class="swiper-slide box">';
                echo '<img src="' . htmlspecialchars($row['cale_imagine']) . '" alt="Product Image">';
                echo '<h1>' . htmlspecialchars($row['nume_produs']) . '</h1>';
                echo '<div class="price">$' . htmlspecialchars($row['pret']) . '/-</div>';
                echo '<div class="stars">';
                // ... Add your stars here ...
                echo '<i class="fa fa-star"></i>';
                echo '<i class="fa fa-star"></i>';
                echo '<i class="fa fa-star"></i>';
                echo '<i class="fa fa-star"></i>';
                echo '<i class="fa fa-star-half"></i>';
                echo '</div>';
                echo '<form action="addprod.php" method="post">';
                echo '<div class="quantity">';
                echo '<button class="btn minus-btn" type="button">-</button>';
                echo '<input type="number" name="cantitate" value="1" min="1" class="quantity-input">';
                echo '<button class="btn plus-btn" type="button">+</button>';
                echo '</div>';
                echo '<div>Cantitate: <span class="quantity-display">1</span></div>';
                // Hidden fields
                echo '<input type="hidden" name="nume_produs" value="' . htmlspecialchars($row['nume_produs']) . '">';
                echo '<input type="hidden" name="pret" value="' . htmlspecialchars($row['pret']) . '">';
                echo '<input type="hidden" name="cale_imagine" value="' . htmlspecialchars($row['cale_imagine']) . '">';
                echo '<input type="hidden" name="categorie_id" value="' . htmlspecialchars($row['categorie_id']) . '">';
                echo '<button type="submit" class="btn">add to cart</button>';
                echo '</form>';
                echo '</div>';
            }
        } else {
            echo "<p>No products found for user 2.</p>";
        }
        ?>
    </div>
</div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.plus-btn, .minus-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const container = btn.closest('.swiper-slide');
            const input = container.querySelector('.quantity-input');
            const display = container.querySelector('.quantity-display');
            const isPlus = btn.classList.contains('plus-btn');
            let currentValue = parseInt(input.value, 10);

            if (isPlus) {
                currentValue += 1;
            } else if (currentValue > 1) {
                currentValue -= 1;
            }

            input.value = currentValue;
            display.textContent = currentValue;
        });
    });
});

</script>


<script>
function removeFromCart(index) {
    if (confirm("Are you sure you want to remove this item?")) {
        $.ajax({
            url: 'remove_from_cart.php',  // Ensure this file exists and can update session cart
            type: 'POST',
            data: { index: index },
            success: function(response) {
                var data = JSON.parse(response);
                if (data.success) {
                    $('#item-' + index).fadeOut(300, function() { $(this).remove(); });
                    $('.total').text('Total: $' + parseFloat(data.newTotal).toFixed(2)); // Update the total displayed
                    alert('Item removed successfully');
                } else {
                    alert(data.message); // Show error message from server
                }
            },
            error: function() {
                alert('Error removing item. Please try again.');
            }
        });
    }
}
</script>


</section>





<!-- Categories-->

<section class="Categories" id="Categories">
    <h1 class="heading">product <span>categories</span></h1>
    <div class="box-container">
        <div class="box">
            <img src="imagine/download1.jpeg" alt="Vegetables">
            <h3>Vegetables</h3>
            <p>Upto 45% Off</p>
            <!-- Note the href attribute is corrected -->
            <a href="category.php?category=Vegetables" class="btn">shop now</a>
        </div>
        <div class="box">
            <img src="imagine/download1.jpeg" alt="Fresh Meat">
            <h3>Fresh Fruits</h3>
            <p>Upto 45% Off</p>
            <a href="category.php?category=Fresh Meat" class="btn">shop now</a>
        </div>
        <div class="box">
            <img src="imagine/download1.jpeg" alt="Daily Products">
            <h3>Dairy Products</h3>
            <p>Upto 45% Off</p>
            <a href="category.php?category=Daily Products" class="btn">shop now</a>
        </div>
        <div class="box">
            <img src="imagine/download1.jpeg" alt="Fresh">
            <h3>Fresh Meat</h3>
            <p>Upto 45% Off</p>
            <a href="category.php?category=Fresh" class="btn">shop now</a>
        </div>
    </div>
</section>


<!-- Reviw -->


<section class="Review" id="Review">
    
<h1 class="heading">Customer's<span>Review </span></h1>
<a href="review.html" class="btn add-review-btn">Add Review</a>
<div class="swipper review-slider">
    <div class="swiper-wrapper">


    <?php
           

            // Configurare conexiune la baza de date
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "shop";

            // Creare conexiune
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Verifică conexiunea
            if ($conn->connect_error) {
                die("Conexiune eșuată: " . $conn->connect_error);
            }

            // Query to fetch review and user name
            $sql = "SELECT r.review, u.email FROM review r JOIN users u ON r.user_id = u.user_id";
            $result = $conn->query($sql);

            // Verifică dacă sunt rezultate
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="swiper-slide box">';
                    echo '<img src="imagine/fruits512.bmp">'; // Update this path as needed
                    echo '<p>' . htmlspecialchars($row['review']) . '</p>';
                    echo '<h3>' . htmlspecialchars($row['email']) . '</h3>';
                    echo '<div class="stars">';
                    echo '<i class="fa fa-star"></i>';
                    echo '<i class="fa fa-star"></i>';
                    echo '<i class="fa fa-star"></i>';
                    echo '<i class="fa fa-star"></i>';
                    echo '<i class="fa fa-star-half"></i>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo "<p>No reviews found.</p>";
            }

            // Închide conexiunea
            $conn->close();
            ?>
        </div>
    </div>



</section>


<!-- blog-->
<section class="Blocs" id="Blocs">
    <h1 class="heading">Our<span>Blogs </span></h1>
   
     
    <div class="box-container">
        
<div class="box">
    <img src="imagine/mar.jpeg">
<div class="content">
<div class="icons">
    <a href="#"><i class="fa fa-user"></i>By User </a>
    <a href="#"><i class="fa fa-calendar"></i>1st. May 2022</a>
</div>
<h3> Fressh and Organic Vegetables And Fruits</h3>
<p>
    I need Money for people Amet Consecture Adipisicing Elit.
    Veniam,Expedita
</p>
<a href="#" class="btn">read more</a> 
</div>

</div>
<div class="box">
    <img src="imagine/download.jpg">
<div class="content">
<div class="icons">
    <a href="#"><i class="fa fa-user"></i>By User </a>
    <a href="#"><i class="fa fa-calendar"></i>1st. May 2022</a>
</div>
<h3> Fressh and Organic Vegetables And Fruits</h3>
<p>
    I need Money for people Amet Consecture Adipisicing Elit.
    Veniam,Expedita
</p>
<a href="#" class="btn">read more</a> 
</div>

</div>
<div class="box">
    <img src="imagine/download1.jpeg">
<div class="content">
<div class="icons">
    <a href="#"><i class="fa fa-user"></i>By User </a>
    <a href="#"><i class="fa fa-calendar"></i>1st. May 2022</a>
</div>
<h3> Fressh and Organic Vegetables And Fruits</h3>
<p>
    I need Money for people Amet Consecture Adipisicing Elit.
    Veniam,Expedita
</p>
<a href="#" class="btn">read more</a> 
</div>

</div>

</div>
</section> 

<!-- footer-->

<section class="footer">
    <div class="box-container">
        <div class="box">
<h3> Doi Pasi <i class="fa fa-shopping-basket"> </i></h3>
<p> Fell Free to follow us on your social media handles all the links are given below.</p>
<div class="share">
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-instagram"></a>
<a href="#" class="fa fa-linkedin"></a>
</div>
</div>
<div class="box">
    <h3> Contact Info </h3>
   <a href="#" class="links"> <i class="fa fa-phone"> +0783104602</i></a>
   <a href="#" class="links"> <i class="fa fa-phone"> +0783105434</i></a>
   <a href="#" class="links"> <i class="fa fa-envelope">banuion99@yahoo.com</i></a>
   <a href="#" class="links"> <i class="fa fa-map-marker"> Pune,Romania</i></a>

    </div>
    <div class="box">
        <h3> Quick Links </h3>
       <a href="#" class="links"> <i class="fa fa-arrow-right"> Home</i></a>
       <a href="#" class="links"> <i class="fa fa-arrow-right"> Features</i></a>
       <a href="#" class="links"> <i class="fa fa-arrow-right"> Products</i></a>
       <a href="#" class="links"> <i class="fa fa-arrow-right"> Categories</i></a>
       <a href="#" class="links"> <i class="fa fa-arrow-right"> Review</i></a>
       <a href="#" class="links"> <i class="fa fa-arrow-right"> Blogs</i></a>
        </div>
        <div class="box">
        <h3>Newsletter</h3>
    <p>Abonează-te pentru ultimele noutăți</p>
    <form action="pagina_tinta.php" method="post">
        <input type="email" placeholder="Adresa ta de email" name="email" class="email" required>
        <input type="submit" value="Abonează-te" class="btn">
    </form>
    <img src="imagine/card2.jpeg" class="payment-img" alt="Metode de Plată">
</div>
    </div>
<div class="credit">Created by<span> Banu Ion</span> | All Right Reserved</div>


</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

<script src="js/script1.js"></script>


</body>
</html>




